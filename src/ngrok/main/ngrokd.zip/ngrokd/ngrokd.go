package main

import (
	"github.com/inconshreveable/ngrok/src/ngrok/server"
)

func main() {
	server.Main()
}
